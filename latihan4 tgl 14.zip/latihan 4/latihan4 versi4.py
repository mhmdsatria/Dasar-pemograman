#1
namabarang1 = input("masukan nama barang :")
hargabarang1 = int (input("masukan harga barang :"))
#2
persen = 10
print("\n")
print("nama barang =",namabarang1)
harga_keuntungan = int(hargabarang1) * int (persen) / 100
print(harga_keuntungan)
harga_jual = int(hargabarang1) + harga_keuntungan
print(namabarang1,'dijual dengan harga:',harga_jual)