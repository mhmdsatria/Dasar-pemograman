

namabarang1 = input("masukan nama barang :")
hargabarang1 = int (input("masukan harga barang :"))
namabarang2 = input("masukan nama barang :")
hargabarang2 = int (input("masukan harga barang :"))
namabarang3 = input("masukan nama barang :")
hargabarang3 = int (input("masukan harga barang :"))

a = 10
persen = (a/100)
print("\n")
print("nama barang =",namabarang1)
hargajual = int (hargabarang1 * persen)
print ("keuntungan =",hargajual)
print("harga total=",hargabarang1 + hargajual)
print("\n")
print("nama barang =",namabarang2)
hargajual = int (hargabarang2 * persen)
print ("keuntungan =",hargajual)
print("harga total=",hargabarang2 + hargajual)
print("\n")
print("nama barang =",namabarang3)
hargajual = int (hargabarang3 * persen)
print ("keuntungan =",hargajual)
print("harga total=",hargabarang3 + hargajual)
#
xlist1 = namabarang1,hargabarang1
xlist2 = namabarang2,hargabarang2
xlist3 = namabarang3,hargabarang3
#
